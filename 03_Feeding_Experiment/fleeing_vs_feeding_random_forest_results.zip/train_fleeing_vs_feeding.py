from pathlib import Path
import numpy as np, pandas as pd, joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, recall_score, precision_score, classification_report, confusion_matrix
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'rf_fleeing_vs_feeding'; OUT.mkdir(exist_ok=True)
def load(folder,stem,label):
    x=pd.read_csv(ROOT/folder/f'{stem}_ml_non_normalized.csv',header=None)
    m=pd.read_csv(ROOT/folder/f'{stem}_source_mapping.csv')
    assert x.shape[1]==202 and len(x)==len(m)
    assert np.isfinite(x.to_numpy()).all()
    assert (m.groupby('Source_Video').size()==24).all()
    return x,pd.Series(np.full(len(x),label)),m['Source_Video'].astype(str).map(lambda s:f'{label}:{s}')
xf,yf,gf=load('fleeing_master','fleeing',1)
xn,yn,gn=load('feeding_master','feeding',0)
X=pd.concat([xf,xn],ignore_index=True);y=pd.concat([yf,yn],ignore_index=True);groups=pd.concat([gf,gn],ignore_index=True)
vt=pd.DataFrame({'group':groups,'label':y}).drop_duplicates('group')
tr,te=train_test_split(vt,test_size=.2,random_state=42,stratify=vt.label)
train=groups.isin(tr.group);test=groups.isin(te.group)
assert not(set(groups[train])&set(groups[test]))
model=RandomForestClassifier(n_estimators=200,random_state=42,n_jobs=-1,class_weight='balanced',min_samples_leaf=2)
model.fit(X.loc[train],y.loc[train]); prob=model.predict_proba(X.loc[test])[:,list(model.classes_).index(1)]
res=pd.DataFrame({'Source_Video':groups.loc[test].to_numpy(),'True_Label':y.loc[test].to_numpy(),'Fleeing_Probability':prob})
res['Predicted_Label']=(res.Fleeing_Probability>=.5).astype(int)
video=res.groupby('Source_Video',as_index=False).agg(True_Label=('True_Label','first'),Fleeing_Probability=('Fleeing_Probability','mean'),Permutation_Count=('Fleeing_Probability','size'))
video['Predicted_Label']=(video.Fleeing_Probability>=.5).astype(int)
def evaluate(df,name):
    truth=df.True_Label;pred=df.Predicted_Label
    metrics={'Accuracy':accuracy_score(truth,pred),'Balanced Accuracy':balanced_accuracy_score(truth,pred),'F1 (Fleeing)':f1_score(truth,pred,zero_division=0),'Fleeing Recall':recall_score(truth,pred,zero_division=0),'Feeding Recall':recall_score(truth,pred,pos_label=0,zero_division=0),'Fleeing Precision':precision_score(truth,pred,zero_division=0)}
    pd.Series(metrics,name='Score').to_csv(OUT/f'{name}_metrics.csv')
    (OUT/f'{name}_classification_report.txt').write_text(classification_report(truth,pred,labels=[0,1],target_names=['Feeding','Fleeing'],zero_division=0))
    cm=confusion_matrix(truth,pred,labels=[0,1]);pd.DataFrame(cm,index=['Actual Feeding','Actual Fleeing'],columns=['Pred Feeding','Pred Fleeing']).to_csv(OUT/f'{name}_confusion_matrix.csv')
    disp=ConfusionMatrixDisplay(cm,display_labels=['Feeding','Fleeing']);disp.plot(cmap='Blues',values_format='d');plt.tight_layout();plt.savefig(OUT/f'{name}_confusion_matrix.png',dpi=180);plt.close()
    return metrics,cm
pm,pcm=evaluate(res,'permutation_level');vm,vcm=evaluate(video,'video_level')
res.to_csv(OUT/'permutation_level_predictions.csv',index=False);video.to_csv(OUT/'video_level_predictions.csv',index=False)
joblib.dump(model,OUT/'random_forest_fleeing_vs_feeding.joblib')
summary=f'''Fleeing vs Feeding Random Forest\nSource videos: Fleeing={len(gf.unique())}, Feeding={len(gn.unique())}\nTrain source videos={len(tr)}, Test source videos={len(te)}\nTrain permutations={int(train.sum())}, Test permutations={int(test.sum())}\nSplit: stratified by source video, test_size=0.2, random_state=42\nModel: 200 trees, class_weight=balanced, min_samples_leaf=2, random_state=42\n\nPERMUTATION LEVEL\n{pm}\nConfusion matrix (rows actual Feeding,Fleeing; columns predicted Feeding,Fleeing):\n{pcm}\n\nVIDEO LEVEL\n{vm}\nConfusion matrix (rows actual Feeding,Fleeing; columns predicted Feeding,Fleeing):\n{vcm}\n'''
(OUT/'results_summary.txt').write_text(summary);print(summary)
